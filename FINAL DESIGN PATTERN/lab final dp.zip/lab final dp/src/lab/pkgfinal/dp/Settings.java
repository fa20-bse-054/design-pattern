/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab.pkgfinal.dp;

/**
 *
 * @author Sabahat
 */
import java.util.ArrayList;
import java.util.List;

// Singleton for Settings
class Settings {
    private static Settings instance;

    private Settings() {
        // private constructor to prevent instantiation
    }

    public static synchronized Settings getInstance() {
        if (instance == null) {
            instance = new Settings();
        }
        return instance;
    }

}
