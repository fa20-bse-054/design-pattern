/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkgfinal.dp;

public class Main {

    public static void main(String[] args) {
        // Singleton for Settings
        Settings settings = Settings.getInstance();

        // Facade for easy interface
        ExamSystemFacade examSystemFacade = new ExamSystemFacade();

        // Strategy for different exam conduction
        ExamConductionStrategy timedExamStrategy = new TimedExamStrategy();
        ExamConductionStrategy openBookExamStrategy = new OpenBookExamStrategy();

        // Builder for Exam
        ExamBuilder examBuilder = new ExamBuilder();
        Exam exam = examBuilder
                .addQuestion(new MCQQuestion())
                .addQuestion(new TrueFalseQuestion())
                // Add other types of questions as needed
                .build();

        // Iterator for Stakeholder or Contents Iteration
        Iterator<Stakeholder> stakeholderIterator = new StakeholderIterator();

        // Template Method for Taking Exams
        ExamTemplate examTemplate = new ExamTemplate() {
            @Override
            protected void conductInstructions() {
                // Implementation for conducting instructions
            }

            @Override
            protected void conductExam() {
                // Implementation for conducting the exam
            }

            @Override
            protected void submitExam() {
                // Implementation for submitting the exam
            }
        };

        // Observer for Real-Time Communication
        Observer parentObserver = new ParentObserver();

        // Example: Using the classes
        examSystemFacade.scheduleExam(exam, timedExamStrategy);
        examSystemFacade.monitorProgress(parentObserver);

        // Example of using the Template Method
        examTemplate.takeExam();

        // Other interactions and demonstrations...
    }
}