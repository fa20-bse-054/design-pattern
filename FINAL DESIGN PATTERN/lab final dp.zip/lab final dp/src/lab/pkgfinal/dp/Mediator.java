/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkgfinal.dp;

// Mediator to control coupling
class Mediator {
    // Mediator logic for communication between different components
}

// Facade for easy interface
class ExamSystemFacade {
    private Mediator mediator;

    public ExamSystemFacade() {
        this.mediator = new Mediator();
    }

    // Facade methods for simplified interactions
    // e.g., scheduleExam, monitorProgress, etc.
}