/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkgfinal.dp;

class Exam {
    private List<Question> questions;

    public Exam(List<Question> questions) {
        this.questions = questions;
    }

    // Methods to get/set questions, conduct exam, etc.
}

// Iterator for Stakeholder or Contents Iteration
interface Iterator<T> {
    boolean hasNext();

    T next();
}