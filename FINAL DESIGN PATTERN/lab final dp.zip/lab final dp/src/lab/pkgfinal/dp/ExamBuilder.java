/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkgfinal.dp;

// Builder for Exam
class ExamBuilder {
    private List<Question> questions = new ArrayList<>();

    public ExamBuilder addQuestion(Question question) {
        questions.add(question);
        return this;
    }

    public Exam build() {
        return new Exam(questions);
    }
}