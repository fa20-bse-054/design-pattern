/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkgfinal.dp;

// Template Method for Taking Exams
abstract class ExamTemplate {
    public void takeExam() {
        // Common steps for taking an exam
        conductInstructions();
        conductExam();
        submitExam();
    }

    protected abstract void conductInstructions();

    protected abstract void conductExam();

    protected abstract void submitExam();
}