/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab.pkgfinal.dp;

// Strategy for different exam conduction
interface ExamConductionStrategy {
    void conductExam();
}

class TimedExamStrategy implements ExamConductionStrategy {
    @Override
    public void conductExam() {
        // Implementation for a timed exam
    }
}